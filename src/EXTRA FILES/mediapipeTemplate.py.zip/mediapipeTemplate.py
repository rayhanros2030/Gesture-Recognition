""" --------------------------------------------------------------
File: mediapipeTemplate.py

This file is a template, or outline, for the various Mediapipe programs you can implement.
It has the basic structure we need to apply Mediapipe models to frames of a video, along with
comments about what you will need to add.
"""

import math
import cv2
import numpy as np

import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
# TODO: Add additional import statements here if needed, more mediapipe, or matplotlib

# -------------------------------------------------------------------------------------
# Below are global variables, used here as constants, which are used by *some* 
MARGIN = 10  # pixels
ROW_SIZE = 10  # pixels
FONT_SIZE = 1
FONT_THICKNESS = 1
CIRCLE_COLOR = (0, 255, 0)   # green
TEXT_COLOR = (0, 255, 255)  # cyan, remembering that this is applied to an RGB, not a BGR, image
HANDEDNESS_TEXT_COLOR = (88, 205, 54) # vibrant green

# -------------------------------------------------------------------------------------
# Functions for visualizing the model's results, including drawing on a Numpy RGB image, as well as helpers
# and plotting functions

# TODO: You must copy the correct functions for each model type from the activity
# TODO:    - All programs will include a function called visualizeResults that creates an RGB image with results

def visualizeResults(rgb_image, detection_result):
    """Draws model results on copy of input image
    Args:
      image: The input RGB image -- Note, RGB, not BGR!
      detection_result: The output from the model to be visualized.
    Returns:
      Copy of input image with results drawn on it
    """
    # TODO: Replace pass with the apprpriate code for the chosen model
    pass


if __name__ == "__main__":
    # Set up model options, and load trained model
    modelPath = "???"    # TODO: Put correct path and model name here
    base_options = python.BaseOptions(model_asset_path=modelPath)   # All models use the same base options
    # TODO: Add additional options here
    options = vision.FaceDetectorOptions(base_options=base_options)
    
    # TODO: Replace None below with the correct call to create the model
    detector = None
    
    # Set up camera
    cap = cv2.VideoCapture(0)
    
    failCount = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            failCount += 1
            if failCount < 5:
                continue
            else:
                break
        failCount = 0
        
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=image)
        detect_result = detector.detect(mp_image)
        
        annot_image = visualizeResults(mp_image.numpy_view(), detect_result)
        vis_image = cv2.cvtColor(annot_image, cv2.COLOR_RGB2BGR)
        cv2.imshow("Detected", vis_image)

        x = cv2.waitKey(30)
        ch = chr(x & 0xFF)
        if ch == 'q':
            break
        # TODO: Some models ask you to add other key responses here
    
    cap.release()
    
    cv2.destroyAllWindows()
    

